# Installation

Dans le projet React existant :

```bash
npm install framer-motion lucide-react
```

Copier `src/components/ui/animated-hud-targeting-ui.tsx` et `src/lib/utils.ts` dans les mêmes dossiers du projet.

Puis intégrer `HudFrame` et `TargetingUI` dans `App.tsx` ou dans l'écran voulu.

Cette version est React + TypeScript + Tailwind et ne dépend pas de Next.js ni de next-themes.
