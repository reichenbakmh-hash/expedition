import { HudFrame, TargetingUI } from "./src/components/ui/animated-hud-targeting-ui";

export default function App() {
  return (
    <HudFrame backgroundColor="#05070a">
      <main className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-black text-white">
        <TargetingUI
          className="relative z-10 h-auto w-[92vw] max-w-[720px]"
          theme="dark"
          pathColors={{ light: "#111827", dark: "#ffffff" }}
        />
      </main>
    </HudFrame>
  );
}
