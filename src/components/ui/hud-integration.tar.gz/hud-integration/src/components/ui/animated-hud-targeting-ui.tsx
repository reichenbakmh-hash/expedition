import React from "react";
import { motion } from "framer-motion";

export interface TargetingUIProps {
  className?: string;
  pathColors?: { light?: string; dark?: string };
  theme?: "light" | "dark";
}

export interface HudFrameProps {
  children?: React.ReactNode;
  backgroundImage?: string;
  backgroundColor?: string;
  backgroundVideo?: string;
}

export function TargetingUI({
  className,
  pathColors = { light: "white", dark: "white" },
  theme = "dark",
}: TargetingUIProps) {
  const color = theme === "dark" ? pathColors.dark ?? "white" : pathColors.light ?? "white";
  const line = (d: string, delay = 0.2) => (
    <motion.path d={d} stroke={color} strokeWidth=".5" fill="none"
      initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
      transition={{ duration: .8, ease: "easeOut", delay }} />
  );

  const dots: [number, number][] = [
    [78,66],[78,70],[82,70],[159,66],[155,70],[159,70],
    [15,107],[20,107],[15,112],[20,112],[217,107],[222,107],[217,112],[222,112],
    [78,154],[78,150],[82,150],[159,154],[155,150],[159,150]
  ];

  return (
    <svg viewBox="0 0 237 220" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} aria-hidden="true">
      {line("M0 1 L74 75")}
      {line("M74 74.75 L164 74.75", 0)}
      {line("M236 1 L164 75")}
      {line("M0 219 L74 145")}
      {line("M74 145.25 L164 145.25", 0)}
      {line("M236 219 L164 145")}

      {dots.map(([cx, cy], i) => (
        <motion.circle key={`${cx}-${cy}`} cx={cx} cy={cy} r=".75" fill={color}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          transition={{ delay: 1.1 + i * .06, duration: .25 }} />
      ))}

      <motion.g transform="translate(29 22)" initial={{ opacity: 0, rotate: 90 }}
        animate={{ opacity: 1, rotate: 0 }} transition={{ duration: 1, ease: "easeOut" }}
        style={{ transformOrigin: "89.5px 87.5px" }}>
        <path d="M89.455 175.334C69.3 175.29 49.79 168.33 34.16 155.61 18.53 142.9 7.74 125.2 3.6 105.49L0 101.89V73.53L3.58 69.96C7.66 50.2 18.43 32.45 34.07 19.7 49.72 6.96 69.28 0 89.46 0s39.74 6.96 55.38 19.7c15.65 12.75 26.42 30.5 30.5 50.26l3.58 3.57v28.35l-3.6 3.6c-4.14 19.72-14.93 37.42-30.56 50.13-15.63 12.72-35.15 19.68-55.3 19.72Z" stroke={color} strokeOpacity=".5" strokeWidth=".75" />
        <motion.circle cx="89.5" cy="87.5" r="80" fill="none" stroke={color} strokeWidth=".5"
          initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.2, delay: .2 }} />
        <motion.circle cx="89.5" cy="87.5" r="72" fill="none" stroke={color} strokeWidth=".5"
          initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.2, delay: .35 }} />

        <g transform="translate(44.5 70)">
          <motion.path d="M22.5 34.37h-5.66l-4.08-4.08m60.15 4.08h-5.67l4.08-4.08M22.5.85h-5.66l-4.08 4.08m64.23-4.08h-5.67l4.08 4.08" stroke={color} strokeWidth=".5"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .7, delay: 1.2 }} />
          <motion.path d="M40.75 12.48h8.46l1 1.72-4.24 7.33h-1.99l-4.23-7.33 1-1.72Z" stroke={color} strokeWidth=".5"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .8, delay: 1.6 }} />
          <motion.path d="M1.5 14.98.4 16.08v3.52l1.08 1.07m86.78-5.69 1.1 1.1v3.52l-1.08 1.07" stroke={color} strokeWidth=".5"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .6, delay: 2 }} />
        </g>
        <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }}>
          <path d="M4 82h1v12H4m171-12h1v12h-1" stroke={color} strokeWidth=".7" />
          <circle cx="4.5" cy="84" r=".5" fill={color} /><circle cx="175.5" cy="84" r=".5" fill={color} />
        </motion.g>
      </motion.g>

      <g transform="translate(90 50)" fill={color} opacity=".3">
        {Array.from({ length: 11 }, (_, i) => <rect key={i} x={28 - i*2.65} y={1+i*.75} width=".8" height="2" />)}
        {Array.from({ length: 11 }, (_, i) => <rect key={i} x={28 + i*2.65} y={1+i*.75} width=".8" height="2" />)}
      </g>
      <g transform="translate(90.5 173) scale(1 -1)" fill={color} opacity=".3">
        {Array.from({ length: 11 }, (_, i) => <rect key={i} x={28 - i*2.65} y={1+i*.75} width=".8" height="2" />)}
        {Array.from({ length: 11 }, (_, i) => <rect key={i} x={28 + i*2.65} y={1+i*.75} width=".8" height="2" />)}
      </g>
    </svg>
  );
}

const clip = `polygon(var(--p) calc(var(--c) + var(--p)),calc(var(--c) + var(--p)) var(--p),calc(50% - var(--n)/2) var(--p),calc(50% - var(--n)/2 + var(--nc)) calc(var(--nd) + var(--p)),calc(50% + var(--n)/2 - var(--nc)) calc(var(--nd) + var(--p)),calc(50% + var(--n)/2) var(--p),calc(100% - var(--c) - var(--p)) var(--p),calc(100% - var(--p)) calc(var(--c) + var(--p)),calc(100% - var(--p)) calc(50% - var(--n)/2),calc(100% - var(--nd) - var(--p)) calc(50% - var(--n)/2 + var(--nc)),calc(100% - var(--nd) - var(--p)) calc(50% + var(--n)/2 - var(--nc)),calc(100% - var(--p)) calc(50% + var(--n)/2),calc(100% - var(--p)) calc(100% - var(--c) - var(--p)),calc(100% - var(--c) - var(--p)) calc(100% - var(--p)),calc(50% + var(--n)/2) calc(100% - var(--p)),calc(50% + var(--n)/2 - var(--nc)) calc(100% - var(--nd) - var(--p)),calc(50% - var(--n)/2 + var(--nc)) calc(100% - var(--nd) - var(--p)),calc(50% - var(--n)/2) calc(100% - var(--p)),calc(var(--c) + var(--p)) calc(100% - var(--p)),var(--p) calc(100% - var(--c) - var(--p)),var(--p) calc(50% + var(--n)/2),calc(var(--nd) + var(--p)) calc(50% + var(--n)/2 - var(--nc)),calc(var(--nd) + var(--p)) calc(50% - var(--n)/2 + var(--nc)),var(--p) calc(50% - var(--n)/2))`;

export function HudFrame({ children, backgroundImage, backgroundColor, backgroundVideo }: HudFrameProps) {
  const vars = { "--p":"8px", "--c":"16px", "--n":"240px", "--nd":"16px", "--nc":"12px" } as React.CSSProperties;
  return <div className="relative min-h-screen w-full">
    <div className="relative z-20 min-h-screen w-full">{children}</div>
    <div className="pointer-events-none fixed inset-0 z-10" style={vars}>
      <div className="absolute inset-0 bg-white" style={{ clipPath: clip, borderRadius:"50px" }} />
      <div className="absolute inset-0 bg-zinc-800 bg-cover bg-center" style={{ clipPath:clip, borderRadius:"50px", backgroundColor, backgroundImage:backgroundImage?`url(${backgroundImage})`:undefined }}>
        {backgroundVideo && <video className="absolute inset-0 h-full w-full object-cover" src={backgroundVideo} autoPlay loop muted playsInline />}
      </div>
    </div>
  </div>;
}
